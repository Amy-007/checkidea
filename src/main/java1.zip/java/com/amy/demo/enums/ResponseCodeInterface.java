package com.amy.demo.enums;


public interface ResponseCodeInterface {

    int getCode();

    String getMsg();

}
