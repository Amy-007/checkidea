package com.amy.demo.vo.response;

import lombok.Data;


public class NameAndCntVO {

    private String date7;

    private Integer successLoginCnt;

    public String getDate7() {
        return date7;
    }

    public void setDate7(String date7) {
        this.date7 = date7;
    }

    public Integer getSuccessLoginCnt() {
        return successLoginCnt;
    }

    public void setSuccessLoginCnt(Integer successLoginCnt) {
        this.successLoginCnt = successLoginCnt;
    }
}
