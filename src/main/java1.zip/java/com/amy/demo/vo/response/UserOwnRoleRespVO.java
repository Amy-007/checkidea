package com.amy.demo.vo.response;

import com.amy.demo.entity.Role;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.List;

public class UserOwnRoleRespVO {

    @ApiModelProperty("所有角色集合")
    private List<Role> allRole;
    @ApiModelProperty(value = "用户所拥有角色集合")
    private List<String> ownRoles;

    public List<Role> getAllRole() {
        return allRole;
    }

    public void setAllRole(List<Role> allRole) {
        this.allRole = allRole;
    }

    public List<String> getOwnRoles() {
        return ownRoles;
    }

    public void setOwnRoles(List<String> ownRoles) {
        this.ownRoles = ownRoles;
    }
}
