package com.amy.demo.entity;

import lombok.Data;

import java.util.List;


public class ChartBean {

    private Integer totalSuccessLoginCnt; //总的成功登录人数 UV

    private Integer todaySuccessLoginCnt; //今日成功登录数 UV

    private Integer weekSuccessLoginCnt; //近一周成功登录数 UV

    private Integer todayFailLoginCnt; //今日失败登录数 PV

    private Integer totalFailLoginCnt; //总的失败登录数 PV

    private Float resourceRate;//剩余资源百分比

    private List<String> dateNameList; //过去一周日期名字

    private List<Integer> loginCntList;//过去一周登录人数列表

    public Integer getTotalSuccessLoginCnt() {
        return totalSuccessLoginCnt;
    }

    public void setTotalSuccessLoginCnt(Integer totalSuccessLoginCnt) {
        this.totalSuccessLoginCnt = totalSuccessLoginCnt;
    }

    public Integer getTodaySuccessLoginCnt() {
        return todaySuccessLoginCnt;
    }

    public void setTodaySuccessLoginCnt(Integer todaySuccessLoginCnt) {
        this.todaySuccessLoginCnt = todaySuccessLoginCnt;
    }

    public Integer getWeekSuccessLoginCnt() {
        return weekSuccessLoginCnt;
    }

    public void setWeekSuccessLoginCnt(Integer weekSuccessLoginCnt) {
        this.weekSuccessLoginCnt = weekSuccessLoginCnt;
    }

    public Integer getTodayFailLoginCnt() {
        return todayFailLoginCnt;
    }

    public void setTodayFailLoginCnt(Integer todayFailLoginCnt) {
        this.todayFailLoginCnt = todayFailLoginCnt;
    }

    public Integer getTotalFailLoginCnt() {
        return totalFailLoginCnt;
    }

    public void setTotalFailLoginCnt(Integer totalFailLoginCnt) {
        this.totalFailLoginCnt = totalFailLoginCnt;
    }

    public Float getResourceRate() {
        return resourceRate;
    }

    public void setResourceRate(Float resourceRate) {
        this.resourceRate = resourceRate;
    }

    public List<String> getDateNameList() {
        return dateNameList;
    }

    public void setDateNameList(List<String> dateNameList) {
        this.dateNameList = dateNameList;
    }

    public List<Integer> getLoginCntList() {
        return loginCntList;
    }

    public void setLoginCntList(List<Integer> loginCntList) {
        this.loginCntList = loginCntList;
    }
}
