package com.amy.demo.vo.response;

import lombok.Data;


@Data
public class NameAndCntVO {

    private String date7;

    private Integer successLoginCnt;
}
